#include "stdio.h"
//#include "winsock2.h"
#include "stdlib.h"
#include "string"
//#include "pch.h"
#include <iostream>

#pragma comment(lib,"ws2_32.lib")

using namespace std;

SOCKET serverSocket;

void recvAndShow()
{
    int r,i=0;
    char buff[256];
    while(1)
    {
        memset(buff,0,256);
        r = recv(serverSocket,buff,255,NULL);
        if(r > 0)
        {
            i++
        }
    }
}

int main(int argc, char const *argv[])
{
    WSADATA wsaData;
    WSAStartup(MAKEWORD(2,2),&wsaData)!=0;
    if(LOBYTE(wsaData,wVersion)!=2||HIBYTE(wsaData.wVersion)!=2)
    {
        cout << "请求版本失败\n"<< endl;
        return -1;
    }
cout << "请求版本成功\n"<< endl;

serverSocket = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
if(serverSocket == INVALID_SOCKET)
{
    cout << "创建socket失败\n" << endl;
    return -1;
}
cout << "创建socket成功\n" <<endl;

addr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
addr.sin_family = AF_INET;
addr.sin_port = htons(10086);

int r = connect(serverSocket,(SOCKEADDR*)&addr,sizeof addr);
id(r == -1)
{
    cout << "连接服务器失败\n"<<endl;
    return -1;
}
    cout << "连接服务器成功\n"<<endl;

CreateThread(NULL,NULL,(LPTHREAD_START_ROUTINE)recvAndShow,NULL,NULL,NULL);
char buff[256];
while(1)
{
    memset(buff,0,256);
    cout << "发送：\n" <<endl;
    cin >> buff;
    r = send(serverSocket,buff,strlen(buff),NULL);
    if(r > 0)
    {
        cout << "发送" << r << "字节成功\n" <<endl;  
    }
}
    return 0;
}
